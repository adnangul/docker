package com.virtualpairprogrammers;

public class VehicleNotFoundException extends Exception {

}
